# email-agent

An agentic AI email assistant that reads your inbox, understands emails
using a **local** LLM (no cloud calls), and notifies you on Discord. It
will eventually let you approve or reject proposed actions before it does
anything on your behalf.

## Design principles

- **Local-first LLM.** All reasoning happens through [Ollama](https://ollama.com)
  running on your own machine (`qwen2.5:1.5b` by default). Nothing about
  email content is sent to a cloud LLM API.
- **Claude Code is a dev tool, not a runtime dependency.** It's used to
  write and edit this code. The running application never calls Claude.
- **Observe → Reason → Plan → Approve → Act → Verify.** The agent never
  autonomously sends an email, deletes anything, or performs an external
  action. It proposes actions; you approve them via Discord before
  anything happens.
- **Build incrementally.** Each milestone adds one capability at a time
  instead of building everything at once.

## Milestone plan

| Milestone | Scope |
|---|---|
| **1 (this one)** | Node project scaffold + verified connection to local Ollama model |
| 2 | Read + parse real emails (Gmail API) |
| 3 | Feed parsed emails to Ollama for classification/summarization |
| 4 | Discord notification for interesting emails |
| 5 | Discord approve/reject flow for proposed actions |
| 6+ | Perform approved actions (send reply, create calendar event, etc.) |

Milestone 1 deliberately does **not** touch email or Discord yet.

## Prerequisites

- Node.js 20.12+ (you're on a version that supports this — check with `node -v`)
- [Ollama](https://ollama.com) installed and running locally
- The model pulled: `ollama pull qwen2.5:1.5b`

## Setup

```bash
cd email-agent
cp .env.example .env   # already done for you in this scaffold — edit if needed
npm start
```

There are no npm dependencies to install for this milestone — the project
uses Node's built-in `fetch` and its built-in `--env-file` flag (see
`package.json`'s `start` script) instead of pulling in `node-fetch` or
`dotenv`. That keeps the dependency tree at zero until a later milestone
genuinely needs a package (e.g. `discord.js`, a Gmail client library).

## What Milestone 1 does

Running `npm start` runs `src/index.js`, which:

1. Sends a plain-text prompt to your local Ollama model and prints the reply.
2. Sends a prompt that asks for a JSON classification of a sample email,
   parses the JSON, and prints the parsed object.

If either step fails, the error message tells you specifically what went
wrong (Ollama not running, wrong model name, invalid JSON from the model,
etc.) rather than a generic stack trace.

## Project structure (so far)

```
email-agent/
├── src/
│   ├── index.js          # Milestone 1 entry point / test script
│   └── llm/
│       └── ollama.js     # Local Ollama API client (generate, generateJSON)
├── .env                  # Local config (git-ignored)
├── .env.example          # Template for .env, safe to commit
├── .gitignore
├── package.json
└── README.md
```

Folders like `agent/`, `email/`, `discord/`, and `tools/` from the original
plan aren't created yet — they'll show up in the milestones that need them,
so the codebase never has empty placeholder files sitting around.

## Troubleshooting

- **"Could not reach Ollama at http://localhost:11434"** — Ollama isn't
  running. Open a terminal and run `ollama list`; if that also fails,
  Ollama's background service isn't up.
- **"Ollama couldn't find model ..."** — run `ollama pull qwen2.5:1.5b`
  and double check the exact name against `ollama list`.
- **"Model was asked for JSON but didn't return valid JSON"** — this can
  happen occasionally with a small 1.5B model. Milestone 3 will add
  retry/repair logic for this; for now it's surfaced as a clear error
  rather than silently failing.
