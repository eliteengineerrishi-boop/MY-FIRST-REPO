// src/llm/ollama.js
//
// Thin wrapper around Ollama's local HTTP API. Nothing in this file talks
// to the network except localhost:11434 (or whatever OLLAMA_BASE_URL is
// set to) — no cloud calls, no API keys.
//
// Ollama API docs (for later reference): https://github.com/ollama/ollama/blob/main/docs/api.md

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen2.5:1.5b';

/**
 * Send a prompt to the local Ollama model and get back its raw text reply.
 *
 * @param {string} prompt - The prompt to send.
 * @param {object} [options]
 * @param {'json'} [options.format] - Pass 'json' to force the model to
 *   reply with valid JSON only (still validate/parse it yourself — the
 *   model can still produce JSON that doesn't match the shape you wanted).
 * @returns {Promise<string>} The model's raw text response.
 */
export async function generate(prompt, { format } = {}) {
  const requestBody = {
    model: OLLAMA_MODEL,
    prompt,
    stream: false, // simpler for now: wait for the full reply instead of streaming chunks
  };
  if (format) requestBody.format = format;

  let response;
  try {
    response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody),
    });
  } catch (err) {
    // This branch fires when the request never even reached Ollama —
    // almost always means the Ollama server isn't running.
    throw new Error(
      `Could not reach Ollama at ${OLLAMA_BASE_URL}. ` +
      `Is Ollama running? On Windows it usually runs automatically in the ` +
      `background after install; try opening a new terminal and running ` +
      `"ollama list" to check. Original error: ${err.message}`
    );
  }

  if (!response.ok) {
    const bodyText = await response.text().catch(() => '(no response body)');
    if (response.status === 404) {
      throw new Error(
        `Ollama couldn't find model "${OLLAMA_MODEL}". ` +
        `Run "ollama pull ${OLLAMA_MODEL}" and check the name matches ` +
        `"ollama list" exactly. Server said: ${bodyText}`
      );
    }
    throw new Error(`Ollama returned HTTP ${response.status}: ${bodyText}`);
  }

  let data;
  try {
    data = await response.json();
  } catch (err) {
    throw new Error(`Ollama's response wasn't valid JSON: ${err.message}`);
  }

  return data.response;
}

/**
 * Like generate(), but asks the model for JSON and parses it for you.
 * Throws a clear error if the model's output can't be parsed — this will
 * happen sometimes with a 1.5B model, so callers should expect it and
 * handle the error rather than assuming it always succeeds.
 *
 * @param {string} prompt
 * @returns {Promise<any>} The parsed JSON value.
 */
export async function generateJSON(prompt) {
  const raw = await generate(prompt, { format: 'json' });
  try {
    return JSON.parse(raw);
  } catch (err) {
    throw new Error(
      `Model was asked for JSON but didn't return valid JSON.\n` +
      `Raw output was:\n${raw}`
    );
  }
}
