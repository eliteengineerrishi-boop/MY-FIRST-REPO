// src/index.js
//
// MILESTONE 1: prove the local Ollama connection works before building
// anything else. This does NOT touch email or Discord yet — that's
// deliberate. See README.md for the full milestone plan.

import { generate, generateJSON } from './llm/ollama.js';

async function main() {
  console.log('--- Milestone 1: Ollama connectivity test ---\n');

  // Test 1: plain text generation, no structure required.
  console.log('[1/2] Sending a plain text prompt...');
  const textReply = await generate(
    'In one short sentence, what does the acronym LLM stand for?'
  );
  console.log('Model replied:');
  console.log('  ' + textReply.trim());
  console.log();

  // Test 2: structured JSON generation — this is the pattern the real
  // agent will use to turn an email into a classification object.
  console.log('[2/2] Sending a prompt that requires structured JSON...');
  const jsonPrompt = `
You classify emails. Respond with ONLY a JSON object, no other text,
in exactly this shape:
{"category": string, "requires_response": boolean, "summary": string}

Email:
Subject: Project deadline moved up
Body: Hi team, just a heads up that the client moved our deadline to this
Friday instead of next Monday. Please adjust your schedules accordingly.
`.trim();

  const jsonReply = await generateJSON(jsonPrompt);
  console.log('Model replied with structured JSON:');
  console.log(jsonReply);
  console.log();

  console.log('--- Milestone 1 complete: Ollama is reachable and usable. ---');
}

main().catch((err) => {
  console.error('\nMilestone 1 test failed:');
  console.error(err.message);
  process.exitCode = 1;
});
